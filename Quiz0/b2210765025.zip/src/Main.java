public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!" + " Abdulakdir Parlak 2210765025 Quiz0");
    }
}